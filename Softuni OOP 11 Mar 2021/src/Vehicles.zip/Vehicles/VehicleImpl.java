package Vehicles;

public interface VehicleImpl {
    void drive(double distance);
    void refuel(double liters);

}
